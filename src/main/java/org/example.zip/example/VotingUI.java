package org.example;

public class VotingUI {
}
